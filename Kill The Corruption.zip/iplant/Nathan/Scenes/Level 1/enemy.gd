extends CharacterBody2D
class_name Cornuption

## --- Node References ---
@onready var enemy_sprite: Sprite2D = $Sprite2D
@onready var ray_cast_2d: RayCast2D = $RayCast2D
@onready var timer: Timer = $Timer
@onready var EnColPol: CollisionPolygon2D = $Cornuption_Area
@onready var body_collision: CollisionPolygon2D = $Hitbox/Body_Collision
@onready var snarl: AudioStreamPlayer2D = $"../Snarl"
@onready var hurting_enemy: AudioStreamPlayer2D = $HurtingEnemy
@onready var start_growl: AudioStreamPlayer2D = $StartGrowl

## --- Movement Constants ---
var WANDER_SPEED :float # Used for WANDER state (renamed from SPEED for clarity)
var CHASE_SPEED : float # Used for CHASE state
var ACCELERATION :float 
## --- Variables ---
var player: CharacterBody2D
var enemy_dir : Vector2 = Vector2(1, 0) # Direction vector for movement, start moving right
var right_bound: Vector2
var left_bound : Vector2

var original_polygon: PackedVector2Array
var flipped_polygon: PackedVector2Array
var original_body_collision: PackedVector2Array
var flipped_body_collision:PackedVector2Array
# Global variables (assuming these are set up correctly in GlobalVars)
# Removed unused global variables for simplicity, but kept necessary ones
var CurEnHlth: int = GlobalVars.CurrentEnemyHealth
enum States {
	WANDER,
	CHASE
}
var CurState = States.WANDER
func _ready():
	seed(hash(Time.get_ticks_msec())) 
	# Collision Polygon Flipping Setup
	if EnColPol and body_collision:
		original_polygon = EnColPol.polygon
		flipped_polygon = PackedVector2Array()
		original_body_collision=body_collision.polygon
		flipped_body_collision=PackedVector2Array()
		# Calculate the flipped polygon (mirroring the X-coordinates)
		for point in original_polygon:
			# FLIP FIX: The pivot point (0,0) is likely the center of the enemy.
			# Flipping by simply negating X should work.
			flipped_polygon.append(Vector2(-point.x, point.y))
		EnColPol.polygon = original_polygon
		for i in original_body_collision:
			flipped_body_collision.append(Vector2(-i.x,i.y))
		body_collision.polygon=original_body_collision
	# Find player body once the scene is ready
	player = GlobalVars.Player_Body
	# Set up wander boundaries relative to the enemy's starting position
	left_bound = self.global_position + Vector2(-125, 0)
	right_bound = self.global_position + Vector2(125, 0)
	# Set initial direction to match the sprite/raycast orientation
	enemy_dir = Vector2(1, 0)
	enemy_sprite.flip_h = false
	ray_cast_2d.target_position = Vector2(500, 0)
	# The timer is only used to end the CHASE state
	timer.one_shot = true # Ensure it runs once per chase timeout
	WANDER_SPEED=randi_range(100,200)
	CHASE_SPEED =randi_range(500,950)
	ACCELERATION=randi_range(200,400)
# Handles the gravity application
func handle_gravity(delta):
	if not is_on_floor():
		velocity.y += get_gravity().y * delta
func change_direction():
	if CurState == States.WANDER:
		# Check if we hit the boundary for the current direction
		if enemy_dir.x == 1 and self.global_position.x >= right_bound.x:
			# Turn Left
			enemy_dir = Vector2(-1, 0)
		elif enemy_dir.x == -1 and self.global_position.x <= left_bound.x:
			# Turn Right
			enemy_dir = Vector2(1, 0)
		# Apply flip based on enemy_dir
		var new_flip = enemy_dir.x < 0
		if enemy_sprite.flip_h != new_flip:
			enemy_sprite.flip_h = new_flip
			EnColPol.polygon = flipped_polygon if new_flip else original_polygon
			body_collision.polygon =flipped_body_collision if new_flip else original_body_collision
			ray_cast_2d.target_position = Vector2(-1000, 0) if new_flip else Vector2(1000, 0)
			ray_cast_2d.force_raycast_update() # IMPORTANT: Update raycast immediately
	else: # CHASE state: follow player
		if is_instance_valid(player):
			# Get direction vector, but ONLY use the X-component for ground enemy movement
			var dir_to_player = player.global_position - self.global_position
			enemy_dir = Vector2(sign(dir_to_player.x), 0)
			# Apply flip based on enemy_dir
			var new_flip = enemy_dir.x < 0
			if enemy_sprite.flip_h != new_flip:
				enemy_sprite.flip_h = new_flip
				EnColPol.polygon = flipped_polygon if new_flip else original_polygon
				body_collision.polygon= flipped_body_collision if new_flip else original_body_collision
				ray_cast_2d.target_position = Vector2(-1000, 0) if new_flip else Vector2(1000, 0)
				ray_cast_2d.force_raycast_update() # IMPORTANT: Update raycast immediately
			if dir_to_player.x>=-100 and dir_to_player.x<=100:
				if not snarl.playing:
					snarl.play() 
				#print("Getting closer")
# Main physics loop
func _physics_process(delta: float):
	# 1. Apply Gravity
	handle_gravity(delta)
	# 2. Check for Player Sight
	# This must be done before movement so the direction is correct for the frame
	hunting_player()
	# 3. Calculate Direction & Orientation
	change_direction()	
	# 4. Calculate Movement and Apply
	handle_movement(delta)
# Movement Application (Move and Slide)
func handle_movement(delta):
	var target_speed = 0.0
	if CurState == States.WANDER:
		target_speed = WANDER_SPEED
	elif CurState == States.CHASE:
		target_speed = CHASE_SPEED
	# Apply desired horizontal movement (ignoring vertical component for ground enemy)
	var desired_velocity_x = enemy_dir.x * target_speed
	velocity.x = move_toward(velocity.x, desired_velocity_x, ACCELERATION * delta)
	move_and_slide()
# Direction change logic for both states
func hunting_player():
	# 1. Check if the ray is hitting the Player
	if ray_cast_2d.is_colliding():
		var collider = ray_cast_2d.get_collider()
		
		if is_instance_valid(collider) and collider is Player:
			# Always start chase if player is seen
			start_chase()
	else: 
		if CurState == States.CHASE:
			# Player has left sight, start the timer to end the chase
			stop_chase()
func _on_timer_timeout():
	# This function executes when the timer runs out, forcing the state back to WANDER
	CurState = States.WANDER
	print("Chase Timeout - Returning to WANDER")
func start_chase():
	if CurState != States.CHASE: # Prevent re-running if already chasing
		print("Start Chase - Player spotted")
		CurState = States.CHASE
		start_growl.play()
	# CRITICAL FIX: If the player is seen, the timer should STOP
	if timer.is_stopped() == false:
		timer.stop()
func stop_chase():
	# The ray is not colliding, meaning the player is out of sight.
	if CurState == States.CHASE:
		if timer.is_stopped():
			print("Stop Chase - Player lost, starting timer")
			timer.start() 
# Health/Damage function (fixed variable name)
func hurt(body):
	print("Owie Wowie")
	if body.CurEnHlth > 1: 
		body.CurEnHlth -= 1
		print("Health remaining: ", CurEnHlth)
		hurting_enemy.play()
		if CurState!=States.CHASE:
			CurState=States.CHASE
	else:
		var death_fade=0.5
		var death_tween=create_tween()
		death_tween.tween_property(enemy_sprite,"modulate",Color(1,1,1,0),death_fade)
		await death_tween.finished
		queue_free()
func attack():
	if CurState==States.CHASE and body_collision:
		pass
func _on_hitbox_body_entered(body):
	if body is Player:
		print(body,"CAN YOU FEEL THE LOVE TONIGHT")
		var direction= enemy_dir
		body.lose_hlth(self,direction)
func Jump():
	pass
