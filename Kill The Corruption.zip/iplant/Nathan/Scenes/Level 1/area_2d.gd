extends CharacterBody2D
class_name Enemy_1
var damage 
@onready var collision_shape_2d: CollisionShape2D = $CollisionShape2D

# Called when the node enters the scene tree for the first time.
func _ready():
	preload("res://Ahmed/Scenes/adventurer.tscn")


@warning_ignore("unused_parameter")
func _on_body_entered(body:Node):
	if body is Player:
		print("hit")
		var hello = body
		hello._playerHurt()
		if GlobalVars.CurrentHealth <= 0:
			get_tree().reload_current_scene()
			GlobalVars.CurrentHealth = GlobalVars.PlayerHealth
