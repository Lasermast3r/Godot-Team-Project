extends Node

@export var PlayerHealth :int = 6
@export var CurrentHealth : int = 6
@export var Has_Dash :bool= false
@export var can_double_jump:int=1
@export var Player_Body:CharacterBody2D
@export var EnemyHealth:int =4
@export var EnemyDamage:int=1
@export var BulletDamage:int=1
@export var CurrentEnemyHealth:int=4
