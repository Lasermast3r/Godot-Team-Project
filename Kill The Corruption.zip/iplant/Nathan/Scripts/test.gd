extends Node2D

@export var Var_dimensions : Vector2i = Vector2i(10,10)
@export var Var_StartingRoom : Vector2i = Vector2i(1,1)
@export var Var_PTG : int = 15
@export var Var_ExtraPaths : int = 3
@export var Var_seed : int = 64
var Var_directions : Array = [Vector2i.UP,Vector2i.RIGHT,Vector2i.DOWN,Vector2i.LEFT]
var Var_weights : Array = [1,1,1,1]
var direction = Vector2i.ZERO
var roomSTR = preload("res://Nathan/Scenes/Level 1/roons/STR_Room1.tscn")
var roomSD = preload("res://Nathan/Scenes/Level 1/roons/SpawnU_Room1.tscn")
var room1SU = preload("res://Nathan/Scenes/Level 1/roons/SpawnR_Room1.tscn")
var room1SR = preload("res://Nathan/Scenes/Level 1/roons/SpawnL_Room1.tscn")
var room1SL = preload("res://Nathan/Scenes/Level 1/roons/SpawnD_Room1.tscn")
var room4WD = preload("res://Nathan/Scenes/Level 1/roons/4WD_Room1.tscn")
var room1RU = preload("res://Nathan/Scenes/Level 1/roons/RD_Room1.tscn")
var room1RD = preload("res://Nathan/Scenes/Level 1/roons/RU_Room1.tscn")
var room1LU = preload("res://Nathan/Scenes/Level 1/roons/LD_Room1.tscn")
var room1LD = preload("res://Nathan/Scenes/Level 1/roons/LUP_Room1.tscn")
var room1LUR = preload("res://Nathan/Scenes/Level 1/roons/LDR_Room1.tscn")
var room1DUR = preload("res://Nathan/Scenes/Level 1/roons/DUR_Room1.tscn")
var room1DUL = preload("res://Nathan/Scenes/Level 1/roons/DUL_Room1.tscn")
var room1DEU = preload("res://Nathan/Scenes/Level 1/roons/DED_Room1.tscn")
var room1DER = preload("res://Nathan/Scenes/Level 1/roons/DER_Room1.tscn")
var room1DEL = preload("res://Nathan/Scenes/Level 1/roons/DEL_Room1.tscn")
var room1DED = preload("res://Nathan/Scenes/Level 1/roons/DEU_Room1.tscn")
var room1BD = preload("res://Nathan/Scenes/Level 1/roons/BossD_Room1.tscn")
var room1BU = preload("res://Nathan/Scenes/Level 1/roons/BossU_Room1.tscn")
var room1BL = preload("res://Nathan/Scenes/Level 1/roons/BossL_Room1.tscn")
var room1BR = preload("res://Nathan/Scenes/Level 1/roons/BossR_Room1.tscn")
var roomNSV = preload("res://Nathan/Scenes/Level 1/roons/UP_Room1.tscn")
var roomLDR = preload("res://Nathan/Scenes/Level 1/roons/LUR_Room1.tscn")

var spawnU = preload("res://Nathan/Scenes/Level 1/roons/SpawnD_Room1.tscn")
var spawnL = preload("res://Nathan/Scenes/Level 1/roons/SpawnL_Room1.tscn")
var spawnD = preload("res://Nathan/Scenes/Level 1/roons/SpawnU_Room1.tscn")
var spawnR = preload("res://Nathan/Scenes/Level 1/roons/SpawnR_Room1.tscn")
var spawnSTRD = preload("res://Nathan/Scenes/Level 1/roons/SpawnSTRD_Room1.tscn")
var spawnSTRU = preload("res://Nathan/Scenes/Level 1/roons/SpawnSTRU_Room1.tscn")
var SpawnSTR = preload("res://Nathan/Scenes/Level 1/roons/SpawnSTR_Room1.tscn")
var spawn4WD = preload("res://Nathan/Scenes/Level 1/roons/4WDSpawn.tscn")

var spawnUR = preload("res://Nathan/Scenes/Level 1/roons/SpawnUR_Room1.tscn")
var spawnUL = preload("res://Nathan/Scenes/Level 1/roons/SpawnDL_Room1.tscn")
var spawnDL = preload("res://Nathan/Scenes/Level 1/roons/SpawnDR_Room1.tscn")
var spawnDR = preload("res://Nathan/Scenes/Level 1/roons/SpawnUL_Room1.tscn")


var locations = []
var dungeon : Array

var RoomDictionary : Dictionary = {
	"PC" : false,
	"SR" : false,
	"neighbours" : {
		"North" : false,
		"East" : false,
		"South" : false,
		"West" : false
	}
	}



# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	if Var_seed == 0:
		@warning_ignore("narrowing_conversion")
		Var_seed = Time.get_unix_time_from_system()
		seed(Var_seed)
	seed(Var_seed)
	#print(Var_seed)
	print("=== Starting generation ===")
	_initalise_dungeon(RoomDictionary)
	_pick_start_room()
	var success = _generate_PTG(Var_StartingRoom, Var_PTG)
	print("Generation success:", success)
	#_print_dungeon()
	_generate_altpaths()
	print("=== Generation complete ===")
	#print(dungeon)
	_repwithtext()
# got this from a toutorial cus idk how to print the array without it being in a straight line :(
#func _print_dungeon() -> void:
	#var Var_dungeon_as_string : String = ""
	#for y in range(Var_dimensions.y -1, -1, -1):
		#for x in Var_dimensions.x:
			#if dungeon[x][y] != RoomDictionary:
				#Var_dungeon_as_string += "[" + str(dungeon[x][y]) + "]"
			#else:
				#Var_dungeon_as_string += "[0]"
		#Var_dungeon_as_string += '\n'
	#print(Var_dungeon_as_string)
##it worked tho so im happy 
func _GDW(Last_direction: Vector2i) -> Array:
	var adjusted_weights = [1,1,1,1]

	#print("hi")
	#print(Last_direction)
	for i in range(adjusted_weights.size()):
		if Var_directions[i] == Last_direction:
			#print(i)
			#print("the last direction was",Last_direction)
			adjusted_weights[i] = (8)
	return(adjusted_weights)

	
func _CWD(Directions: Array, Weight: Array) -> Vector2i:
	var total_weight = 0
	for w in Weight:
		total_weight += w
	#print(total_weight)
	
	var random_val = randi() % total_weight
	#print(random_val)
	for i in range(Weight.size()):
		random_val -= Weight[i]
		if random_val < 0:
			#print(Directions[i])
			return Directions[i]
			
	
	return Directions[0]
func _generate_PTG(from: Vector2i, length: int, Last_direction := Vector2i.ZERO) -> bool:
	if length == 0:
		return true
	var current = from
	
	#calls the choose weighted direction function to get the inital direction at 25% chance for each direction 
	var Direction = _CWD(Var_directions , _GDW(direction))
	#print (Direction)
	for i in range(length):
		if Last_direction == Vector2i.ZERO:
			direction = _CWD(Var_directions,Var_weights)
		else:
			direction = _CWD(Var_directions, _GDW(Last_direction))
	direction = Direction	
	#the old random direction rubish ignore for now x 
	#match randi_range(0,3):
		#0:
			#direction = Vector2i.UP
		#1:
			#direction = Vector2i.RIGHT
		#2:
			#direction = Vector2i.DOWN
		#3:
			#direction = Vector2i.LEFT
#this recursive section is just pathing to ensure that the path continues even if it hits the edge of the array
	for i in range(4):
		
		
		var next = current + direction
		
		#print("Trying direction: ", direction, " from ", current, " to ", next) 

		if (
			next.x >= 0 and next.x < Var_dimensions.x and
			next.y >= 0 and next.y < Var_dimensions.y and
			dungeon[next.x][next.y]["PC"] == false
		):
	
			if length == 1:

				dungeon[next.x][next.y]["PC"] = true
			else:
				dungeon[next.x][next.y]["PC"] = true # store number as string
			if _generate_PTG(next, length - 1, direction):
				return true
			else:
				dungeon[next.x][next.y]["PC"] = false


		# rotate 90 degrees clockwise
		direction = Vector2i(direction.y, -direction.x)

	return false
func _initalise_dungeon(Dict : Dictionary) -> void:
	for x in Var_dimensions.x:
		dungeon.append([])
		for y in Var_dimensions.y:
			dungeon[x].append(Dict.duplicate(true))
func _generate_altpaths() -> void:
	for c in Var_ExtraPaths:
			for x in Var_dimensions.x:
				for y in Var_dimensions.y:
					pass
func _pick_start_room() -> void:
	var DungeonRoomDict = RoomDictionary.duplicate(true)
	DungeonRoomDict["PC"] = true
	DungeonRoomDict["SR"] = true
	dungeon[Var_StartingRoom.x][Var_StartingRoom.y] = DungeonRoomDict



func _repwithtext() -> void:
	

	for x in range(dungeon.size()):
		for y in range(dungeon[x].size()):
			var TempDict : Dictionary = dungeon[x][y].duplicate(true)
			if TempDict["PC"] == true:
				locations.append(Vector2(x, y))
				var NorthC = Vector2(x ,y - 1)
				var EastC = Vector2(x + 1,y)
				var SouthC = Vector2(x,y + 1)
				var WestC = Vector2(x - 1, y)
				var Temp : Dictionary = dungeon[x][y].duplicate(true)
				if NorthC.y >= 0:
					if dungeon[NorthC.x][NorthC.y]["PC"] == true :
						Temp["neighbours"]["North"] = true
				if EastC.x < Var_dimensions.x:
					if dungeon[EastC.x][EastC.y]["PC"] == true:
						Temp["neighbours"]["East"] = true
				if SouthC.y < Var_dimensions.y:
					if dungeon[SouthC.x][SouthC.y]["PC"] == true:
						Temp["neighbours"]["South"] = true
				if WestC.x >= 0:
					if dungeon[WestC.x][WestC.y]["PC"] == true:
						Temp["neighbours"]["West"] = true
				dungeon[x][y] = Temp
				print(dungeon[x][y])
				print("working")
				var matchtestinput : String = ""
				if dungeon[x][y]["neighbours"]["North"] == true:
					matchtestinput = matchtestinput + "T"
				else:
					matchtestinput = matchtestinput + "F"
					
				if dungeon[x][y]["neighbours"]["East"] == true:
					matchtestinput = matchtestinput + "T"
				else:
					matchtestinput = matchtestinput + "F"
					
				if dungeon[x][y]["neighbours"]["South"] == true:
					matchtestinput = matchtestinput + "T"
				else:
					matchtestinput = matchtestinput + "F"
					
				if dungeon[x][y]["neighbours"]["West"] == true:
					matchtestinput = matchtestinput + "T"
				else:
					matchtestinput = matchtestinput + "F"
					
				print(matchtestinput)
				print(locations)
				match matchtestinput:
					"TFFF":
						if dungeon[x][y]["SR"] == false:
							print("dead end north door")
							var xlo = 1984 * x
							var ylo = -1984 * y
							var instance1 = room1DEU.instantiate()
							instance1.position = Vector2(xlo,ylo)
							add_child(instance1)
						else:
							var xlo = 1984 * x
							var ylo = -1984 * y
							var instance288 = spawnU.instantiate()
							instance288.position = Vector2(xlo,ylo)
							add_child(instance288)
							var adventurer = $Adventurer
							adventurer.position = Vector2(xlo + 952,ylo)
					"TTFF":
						if dungeon[x][y]["SR"] == false:
							print("north and east corner")
							var xlo = 1984 * x
							var ylo = -1984 * y
							var instance3 = room1RU.instantiate()
							instance3.position = Vector2(xlo,ylo)
							add_child(instance3)
						else:
							var xlo = 1984 * x
							var ylo = -1984 * y
							var instance26 = spawnUR.instantiate()
							instance26.position = Vector2(xlo,ylo)
							add_child(instance26)
							var adventurer = $Adventurer
							adventurer.position = Vector2(xlo + 952,ylo)
					"TTTF":
						if dungeon[x][y]["SR"] == false:
							print("North east south branch")
							var xlo = 1984 * x
							var ylo = -1984 * y
							var instance4 = room1DUR.instantiate()
							instance4.position = Vector2(xlo,ylo)
							add_child(instance4)
					"TTTT":
						if dungeon[x][y]["SR"] == false:
							var xlo = 1984 * x
							var ylo = -1984 * y
							var instance5 = room4WD.instantiate()
							instance5.position = Vector2(xlo,ylo)
							add_child(instance5)
							print("4 way drive")
						else:
							var xlo = 1984 * x
							var ylo = -1984 * y
							var instance6 = spawn4WD.instantiate()
							instance6.position = Vector2(xlo,ylo)
							add_child(instance6)
							var adventurer = $Adventurer
							adventurer.position = Vector2(xlo + 952,ylo)
					"FTTT":
						if dungeon[x][y]["SR"] == false:
							var xlo = 1984 * x
							var ylo = -1984 * y
							var instance7 = roomLDR.instantiate()
							instance7.position = Vector2(xlo,ylo)
							add_child(instance7)
							print("east south west branch")
						else:
							var xlo = 1984 * x
							var ylo = -1984 * y
							var instance8 = spawnSTRD.instantiate()
							instance8.position = Vector2(xlo,ylo)
							add_child(instance8)
							var adventurer = $Adventurer
							adventurer.position = Vector2(xlo + 952,ylo)
					"FFTT":
						if dungeon[x][y]["SR"] == false:
							var xlo = 1984 * x
							var ylo = -1984 * y
							var instance9 = room1LD.instantiate()
							instance9.position = Vector2(xlo,ylo)
							add_child(instance9)
							print("south west corner")
						else:
							var xlo = 1984 * x
							var ylo = -1984 * y
							var instance27 = spawnDR.instantiate()
							instance27.position = Vector2(xlo,ylo)
							add_child(instance27)
							var adventurer = $Adventurer
							adventurer.position = Vector2(xlo + 952,ylo)
					"FFFT":
						if dungeon[x][y]["SR"] == false:
							var xlo = 1984 * x
							var ylo = -1984 * y
							var instance10 = room1DEL.instantiate()
							instance10.position = Vector2(xlo,ylo)
							add_child(instance10)
							print("dead end west door")
						else:
							var xlo = 1984 * x
							var ylo = -1984 * y
							var instance11 = spawnL.instantiate()
							instance11.position = Vector2(xlo,ylo)
							add_child(instance11)
							var adventurer = $Adventurer
							adventurer.position = Vector2(xlo + 952,ylo)
					"TFTF":
						if dungeon[x][y]["SR"] == false:
							var xlo = 1984 * x
							var ylo = -1984 * y
							var instance12 = roomNSV.instantiate()
							instance12.position = Vector2(xlo,ylo)
							add_child(instance12)
							print("north south vertical ")
						else:
							var xlo = 1984 * x
							var ylo = -1984 * y
							var instance28 = spawnUL.instantiate()
							instance28.position = Vector2(xlo,ylo)
							add_child(instance28)
							var adventurer = $Adventurer
							adventurer.position = Vector2(xlo + 952,ylo)
					"FTFT":
						if dungeon[x][y]["SR"] == false:
							var xlo = 1984 * x
							var ylo = -1984 * y
							var instance13 = roomSTR.instantiate()
							instance13.position = Vector2(xlo,ylo)
							add_child(instance13)
							print("west east Straight room ")
						else:
							var xlo = 1984 * x
							var ylo = -1984 * y
							var instance14 = SpawnSTR.instantiate()
							instance14.position = Vector2(xlo,ylo)
							add_child(instance14)
							var adventurer = $Adventurer
							adventurer.position = Vector2(xlo + 952,ylo)
					"FTTF":
						if dungeon[x][y]["SR"] == false:
							var xlo = 1984 * x
							var ylo = -1984 * y
							var instance15 = room1RD.instantiate()
							instance15.position = Vector2(xlo,ylo)
							add_child(instance15)
							print("East south corner")
						else:
							var xlo = 1984 * x
							var ylo = -1984 * y
							var instance29= spawnDR.instantiate()
							instance29.position = Vector2(xlo,ylo)
							add_child(instance29)
							var adventurer = $Adventurer
							adventurer.position = Vector2(xlo + 952,ylo)
					"TFFT":
						if dungeon[x][y]["SR"] == false:
							var xlo = 1984 * x
							var ylo = -1984 * y
							var instance16 = room1LU.instantiate()
							instance16.position = Vector2(xlo,ylo)
							add_child(instance16)
							print("north west corner")
						else:
							var xlo = 1984 * x
							var ylo = -1984 * y
							var instance222 = spawnUL.instantiate()
							instance222.position = Vector2(xlo,ylo)
							add_child(instance222)
							var adventurer = $Adventurer
							adventurer.position = Vector2(xlo + 952,ylo)
					"TFTT":
						if dungeon[x][y]["SR"] == false:
							var xlo = 1984 * x
							var ylo = -1984 * y
							var instance17 = room1DUL.instantiate()
							instance17.position = Vector2(xlo,ylo)
							add_child(instance17)
							print("North south West Branch")
					"TTFT":
						if dungeon[x][y]["SR"] == false:
							var xlo = 1984 * x
							var ylo = -1984 * y
							var instance18 = room1LUR.instantiate()
							instance18.position = Vector2(xlo,ylo)
							add_child(instance18)
							print("north east west branch")
						else:
							var xlo = 1984 * x
							var ylo = -1984 * y
							var instance19 = spawnSTRU.instantiate()
							instance19.position = Vector2(xlo,ylo)
							add_child(instance19)
							var adventurer = $Adventurer
							adventurer.position = Vector2(xlo + 952,ylo)
					"FTFF":
						if dungeon[x][y]["SR"] == false:
							var xlo = 1984 * x
							var ylo = -1984 * y
							var instance20 = room1DER.instantiate()
							instance20.position = Vector2(xlo,ylo)
							add_child(instance20)
							print("dead end east")
						else:
							var xlo = 1984 * x
							var ylo = -1984 * y
							var instance21 = spawnR.instantiate()
							instance21.position = Vector2(xlo,ylo)
							add_child(instance21)
							var adventurer = $Adventurer
							adventurer.position = Vector2(xlo + 952,ylo)
					"FFTF":
						if dungeon[x][y]["SR"] == false:
							var xlo = 1984 * x
							var ylo = -1984 * y
							var instance22 = room1DED.instantiate()
							instance22.position = Vector2(xlo,ylo)
							add_child(instance22)
							print("west dead end")
						else:
							var xlo = 1984 * x
							var ylo = -1984 * y
							var instance23 = spawnL.instantiate()
							instance23.position = Vector2(xlo,ylo)
							add_child(instance23)
							var adventurer = $Adventurer
							adventurer.position = Vector2(xlo + 952,ylo)
					"FFFF":
						if dungeon[x][y]["SR"] == false:
							var xlo = 1984 * x
							var ylo = -1984 * y
							var instance24 = room4WD.instantiate()
							instance24.position = Vector2(xlo,ylo)
							add_child(instance24)
							print("west dead end")
						else:
							var xlo = 1984 * x
							var ylo = -1984 * y
							var instance25 = spawn4WD.instantiate()
							instance25.position = Vector2(xlo,ylo)
							add_child(instance25)
							var adventurer = $Adventurer
							adventurer.position = Vector2(xlo + 952,ylo)
