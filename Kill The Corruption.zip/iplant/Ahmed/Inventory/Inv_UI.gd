extends Control #Inv_UI

@onready var inv:Inv=preload("res://Ahmed/Inventory/Player_Inv.tres") #Loads the Player's Inventory
@onready var slots:Array = $TextureRect/GridContainer.get_children() #gets all the panels in an array 
var is_open:bool=false # variable as a condition to make the inventory visible or not
func update_slots():# this function will change what will be in the panels when something is added/removed
	for i in range(min(inv.slots.size(),slots.size())):
		slots[i].update(inv.slots[i])
func _ready() -> void:# makes sure at start of game the inventory isn't open
	inv.update.connect(update_slots)
	update_slots()
	close()
func _process(_delta:float)->void: #inventory is toggled open/closed with the key "Q"
	if Input.is_action_just_pressed("InventoryToggle"):
		if is_open:
			print("Close Inv")
			open()
		else:
			print("Open Inv")
			close()
	if Input.is_action_just_pressed("Restart"):
		close()
		empty()

func open(): #opens inventory
	self.visible=true
	is_open=false

func close():# closes inventory
	self.visible=false
	is_open=true

func empty():
	# --- CRITICAL FIX: Clear the data in the Inventory Resource first ---
	# NOTE: You must implement a 'clear_data()' method in your 'Inv' resource script
	# (e.g., 'Player_Inv.tres') that resets the inv.slots array.
	if inv.has_method("clear_data"):
		inv.clear_data()
	# The 'update_slots' function then correctly reads the cleared data and updates the UI.
	update_slots()
