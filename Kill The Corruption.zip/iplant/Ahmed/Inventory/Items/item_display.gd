extends Panel
@onready var item_visual: Sprite2D = $Item_Display#item_visual is The resource that is used to represent the ability
func update(slot:InvSlot): #if item visual is false/true it changes the visibility
	if slot == null or slot.item == null:
		item_visual.visible = false
		item_visual.texture = null
	else:
		item_visual.visible = true
		item_visual.texture= slot.item.texture
	print(item_visual.visible)
