extends Resource
class_name Inv
signal update
@export var slots: Array[InvSlot]#
func insert(item:InvItem):#checks is item is in slot
	var itemslots = slots.filter(func(slot): return slot.item == item)#basically goes through all the items in the slot to see if there is a matching item to add onto
	if !itemslots.is_empty():# if there is an item in a slot
		itemslots[0].amount +=1 #the amount in that slot increases by 1
	else:
		var emptyslots= slots.filter(func(slot): return slot.item == null)
		if !emptyslots.is_empty(): #if there isn't then there is a new item to that slot and the amount is set to 1
			emptyslots[0].item=item
			emptyslots[0].amount=1
	update.emit()
func clear_data():
	# Resets all slots by setting the item to null and amount to 0.
	for slot in slots:
		slot.item = null
		slot.amount = 0
	# Notify listeners (Inv_UI) that the data has changed
	update.emit()
