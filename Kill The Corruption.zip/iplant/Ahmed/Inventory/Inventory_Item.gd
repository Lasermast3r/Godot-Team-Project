extends Resource
class_name InvItem# Item will have a name, and a texture as defined. This is used to create the dash, jump,etc item as a resource
@export var name :String=""
@export var texture: Texture2D
