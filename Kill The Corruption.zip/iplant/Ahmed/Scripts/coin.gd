extends Area2D
@export var item:InvItem
var direction := Input.get_axis("move_left", "move_right")
var Has_Dash : bool= GlobalVars.Has_Dash
var player =null
func _on_body_entered(body):
	if body is Player:
		print("Speed Boost")
		body.activate_dash()
		body.collect(item)
		queue_free()
