extends Area2D
var can_double_jump:= GlobalVars.can_double_jump
@export var item:InvItem
func _on_body_entered(adventurer: Node2D) -> void:
	if adventurer is CharacterBody2D:
		print("Jump Boost")
		adventurer.activate_double_jump()
		adventurer.collect(item)
		queue_free()
