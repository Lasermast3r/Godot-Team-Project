extends Area2D
class_name Bullet

var speed :float = 3000.0
var direction: Vector2 = Vector2.ZERO

const rest_of_sounds = [
	preload("res://Ahmed/Audio/Bullet_Hit.wav"),
	preload("res://Ahmed/Audio/Bullet_Hit_2.wav"),
	preload("res://Ahmed/Audio/Bullet_Hit_3.wav"),
]
const Enemy_Hit_Sounds = [
	preload("res://Ahmed/Audio/Flesh_Hit.wav"),
	preload("res://Ahmed/Audio/Flesh_Hit_2.wav"),
	preload("res://Ahmed/Audio/Flesh_Hit_3.wav"),
]
func _ready():
	connect("body_entered", Callable(self, "_on_body_entered"))
func _process(delta: float) -> void:
	position += direction * speed * delta
func _on_body_entered(body):
	var sound_set: Array = []
	if body is not Player:
		if body is Cornuption:
			sound_set = Enemy_Hit_Sounds
			print("Hit Cornuption")
			body.hurt(body)
			
			
		else:
			sound_set = rest_of_sounds
			print("Hit ",body)
		if not sound_set.is_empty():
			_play_one_shot_sound(sound_set)
		queue_free()
func _play_one_shot_sound(sound_set: Array):
	var sound_to_play = sound_set.pick_random()
	var player = AudioStreamPlayer2D.new()
	player.global_position = position
	player.stream = sound_to_play
	player.autoplay = true
	player.max_distance = 1000.0
	get_tree().root.add_child(player)
	player.connect("finished", Callable(player, "queue_free"))
