extends Area2D
@onready var timer: Timer = $Timer


func _on_body_entered(body: Node2D) -> void:
	if body is Player:
		print("You died") # Replace with function body.
		body.get_node("CollisionShape2D").queue_free()
		body.handle_death()
