extends CharacterBody2D
class_name Player

const WeKiOf = 30
const SPEED = 900
const Enemy_Layer=3 # CRITICAL: Ensure this is the correct collision layer for your enemies.
@export var inv:Inv
@onready var player_animated: AnimatedSprite2D = $AnimatedSprite2D
@onready var weed_killer: Sprite2D = $WeedKiller # Assuming WeedKiller is a direct child of Player
@onready var bullet = preload("res://Ahmed/Scenes/Bullet.tscn")
@onready var cornyuppy=preload("res://Nathan/Scenes/Level 1/EnemyTest.tscn")
@onready var bullet_timer: Timer = $Bullet_timer

@onready var gunshot: AudioStreamPlayer2D = $Gunshot
@onready var breathing: AudioStreamPlayer2D = $Breathing
@onready var jumping: AudioStreamPlayer2D = $Jumping
@onready var hurt: AudioStreamPlayer2D = $Hurt
@onready var death: AudioStreamPlayer2D = $Death

const grass_rustles = [
	preload("res://Ahmed/Audio/Grass_Rustle_1.wav"),
	preload("res://Ahmed/Audio/Grass_Rustle_2.mp3"),
	preload("res://Ahmed/Audio/Grass_Rustle_3.mp3")
]
@onready var timer: Timer = $Timer # Used for knockback, shooting cooldown, and invulnerability duration.

const JUMP_VELOCITY = -1500
var Has_Dash :bool= GlobalVars.Has_Dash
var is_dashing :bool=false
var dash_speed :int= 2000
var dash_duration:float= 0.1
var dash_direction = 0
var gravity:float= 4
var is_in_knockback = false
var max_jumps : int = GlobalVars.can_double_jump
var jumps_left : int = GlobalVars.can_double_jump
var can_double_jump= GlobalVars.can_double_jump
var is_invulnerable=false # State variable for I-frames

var PlayHlth:int= GlobalVars.PlayerHealth
var CurPlayHlth:int= GlobalVars.CurrentHealth
var Player_Dead: bool = false

func _ready():
	GlobalVars.Player_Body=self
	# NOTE: If WeedKiller is not a child of AnimatedSprite2D, 
	# its position should be adjusted relative to the player's center.
	# WeKiOf is currently the horizontal offset from the center.
	weed_killer.position.x=-WeKiOf 
	print(SPEED,can_double_jump,max_jumps,jumps_left)

func _physics_process(delta: float) -> void:
	if CurPlayHlth <= 0:
		set_process_input(false)

	if Input.is_action_just_pressed("Restart"):
		restart()
	if Input.is_action_just_pressed("Die"):
		handle_death()
	if not is_on_floor():
		velocity.y += get_gravity().y * delta * gravity
	else:
		jumps_left = max_jumps
		
	if is_invulnerable:
		var flash_speed = 8.0
		var alpha = sin(Engine.get_physics_frames() * flash_speed) * 0.5 + 0.5
		player_animated.modulate = Color(1.0, 1.0, 1.0, alpha)
		weed_killer.modulate = Color(1.0,1.0,1.0,alpha)
	else:
		player_animated.modulate = Color(1.0, 1.0, 1.0, 1.0)
		weed_killer.modulate=Color(1.0,1.0,1.0,1.0)
	var direction := 0.0

	if not is_in_knockback:
		direction = Input.get_axis("move_left", "move_right")

		if Has_Dash == true and Input.is_action_just_pressed("sprint"):
			start_dash()
			
		if Input.is_action_just_pressed("jump") and jumps_left > 0:
			velocity.y = JUMP_VELOCITY
			jumps_left -= 1
			jumping.play()
			print("Jumping")

		if not is_dashing:
			if direction != 0:
				velocity.x = direction * SPEED
				dash_direction = sign(direction)
				var sound_set = grass_rustles
				if not sound_set.is_empty():
					_play_footsteps(sound_set)
			else:
				velocity.x = move_toward(velocity.x, 0, SPEED)

	if direction != 0:
		var facing_right = direction > 0
		
		player_animated.flip_h = facing_right
		weed_killer.flip_h = facing_right
		
		weed_killer.position.x = WeKiOf * sign(direction) 

	if is_dashing:
		player_animated.play("Dash")
	elif not is_on_floor():
		if velocity.y < 0:
			player_animated.play("Jump")
	elif direction != 0:
		player_animated.play("Run")
	else:
		player_animated.play("Idle")
		
	if Input.is_action_just_pressed("Shoot"):
		if bullet_timer.is_stopped():
			print("Shot")
			gunshot.play()
			bullet_timer.start(0.3)
			var bullet_temp = bullet.instantiate()
			bullet_temp.global_position = global_position
			var mouse_pos = get_global_mouse_position()
			@warning_ignore("shadowed_variable")
			var dir = (mouse_pos - global_position).normalized()
			bullet_temp.rotation = dir.angle()
			bullet_temp.direction = dir
			get_tree().current_scene.add_child(bullet_temp)
	if Input.is_action_just_pressed("Spawn"):
		var enemy =cornyuppy.instantiate()
		var mouse_pos = get_global_mouse_position()
		enemy.global_position=mouse_pos
		get_tree().current_scene.add_child(enemy)
	move_and_slide()
	
func activate_double_jump():
	max_jumps=2
	jumps_left=2
	return can_double_jump	

func activate_dash():
	Has_Dash=true
	return Has_Dash

func start_dash():
	# Only start dash if the player is not currently dashing or invulnerable
	if not is_dashing and not is_invulnerable:
		if dash_direction == 0:
			dash_direction = 1 if player_animated.flip_h else -1
		
		is_dashing = true
		velocity.x = dash_direction * dash_speed
		
		await get_tree().create_timer(dash_duration).timeout
		
		is_dashing = false
		if is_on_floor():
			velocity.x = 0
		Has_Dash = true

func collect(item):
	print("Collected Item")
	inv.insert(item)

func lose_hlth(body, direction):
	if body is Cornuption:
		# --- CRITICAL: INVULNERABILITY CHECK MUST BE FIRST ---
		if is_invulnerable:
			print("Damage blocked by invulnerability frames.")
			return
			
		print("Player is taking damage from Cornuption.")
		
		var knockback_force = 300
		var knockup_force = 900

		if CurPlayHlth > 0 and !is_invulnerable:
			
			# 1. APPLY DAMAGE
			CurPlayHlth -= 1
			print("Player health remaining:", CurPlayHlth)
			
			# 2. ACTIVATE INVULNERABILITY & KNOCKBACK
			is_invulnerable = true
			is_in_knockback = true
			
			# DISABLE COLLISION MASK FOR ENEMY LAYER: Player ignores enemy collision
			set_collision_mask_value(Enemy_Layer, false)
			print("Collision Mask for Layer ", Enemy_Layer, " DISABLED.")
			
			# 3. APPLY KNOCKBACK VELOCITY
			velocity.x = direction.x * knockback_force
			velocity.y = -knockup_force
			hurt.play()
			
			# 4. START DURATION TIMER (0.3s)
			timer.start(0.3)
			
		else:
			print("Player defeated.")
			handle_death()

func handle_death():
	if Player_Dead:
		return
	death.play()
	Player_Dead = true
	print("SLooooow Motiooon")
	Engine.time_scale = 0.5
	var death_fade=0.5
	var death_tween=create_tween()
	death_tween.tween_property(player_animated,"modulate",Color(1,1,1,0),death_fade)
	death_tween.parallel().tween_property(weed_killer,"modulate",Color(1,1,1,0),death_fade)
	await death_tween.finished
	restart()
	
func restart():
	Engine.time_scale = 1.0
	CurPlayHlth = PlayHlth
	Player_Dead = false
	
	# --- CRITICAL FIX: Ensure Inventory is cleared here ---
	if inv and inv.has_method("clear_data"):
		inv.clear_data()
		print("Inventory data cleared during restart.")
	
	get_tree().reload_current_scene()

func _play_footsteps(sound_set):
	var sound_to_play = sound_set.pick_random()
	
	var player = AudioStreamPlayer2D.new()
	player.global_position = position
	player.stream = sound_to_play
	player.autoplay = true
	player.max_distance = 1000.0
	get_tree().root.add_child(player)
	player.connect("finished", Callable(player, "queue_free"))

# This function is connected to the $Timer timeout signal
func _on_timer_timeout() -> void:
	# Ends the knockback and invulnerability states
	is_in_knockback = false
	is_invulnerable = false
	
	# RE-ENABLE COLLISION MASK FOR ENEMY LAYER: Player sees enemy collision again
	set_collision_mask_value(Enemy_Layer, true)
	print("Collision Mask for Layer ", Enemy_Layer, " ENABLED.")

	# Clear horizontal velocity so the player doesn't slide indefinitely after knockback ends
	velocity.x = 0
	# Ensure the sprite modulation is reset (stops flashing)
	player_animated.modulate = Color(1.0, 1.0, 1.0, 1.0) # Reset to full visibility
	
func _on_bullet_timer_timeout():
	bullet_timer.stop()
