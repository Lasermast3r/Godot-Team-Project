extends Resource
class_name InvSlot #This resource will determine how much of the item
@export var item:InvItem
@export var amount:int
